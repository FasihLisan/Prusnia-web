</div>
</div>
</div>
</section>
<!-- Bootstrap % Fontawesome -->
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="./assets/bootstrap/js/popper.min.js"></script>
<script src="./assets/fontawesome/js/all.js"></script>
<script src="./assets/js/jquery.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
<script src="./assets/owl_carousel/owl.carousel.js"></script><!-- owl carousel -->
<script src="./assets/js/bookCenter.js" language="JavaScript" type="text/javascript"></script>
<script src="./assets/js/script.js"></script>

</body>

</html>