<?php
define('BASE_URL', 'http://localhost/perusnia/');
