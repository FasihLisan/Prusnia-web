	<?php
  require_once('../controller/api/bookController.php');
  $user = new bookController();


  if (isset($_GET['transaction_id'])) {
    $user->insertMyBook($_GET['transaction_id']);
  } else {
    $response = [
      "status" => 401,
      "message" => "prams tramsaction id required"
    ];
    echo json_encode($response);
  }
